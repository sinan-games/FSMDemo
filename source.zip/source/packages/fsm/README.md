# fsm

This library was generated with [Nx](https://nx.dev).


## Running unit tests

Run `yarn test` to execute the unit tests via [Jest](https://jestjs.io).

## build

Run `yarn build`

## add Dependencies

`cd packages/fsm`
`npx lerna add lis --dev`