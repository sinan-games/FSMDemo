import fs from "fs-extra"
// @ts-ignore
import path from "path"
import pack from "./package.json"
import rootPack from "../../package.json"
// @ts-ignore
let outputRoot = path.join(__dirname, "dist")
// @ts-ignore
let saveRoot = path.join(__dirname,"..","..","dist");
let dtsCont = fs.readFileSync(outputRoot + "/index.d.ts", "utf8")

dtsCont = dtsCont.replace(/declare /g, "")
dtsCont = `namespace ${pack.globalname} {
        ${dtsCont.replace(/\t/g, "\t\t")
        .replace(/\n/g, "\n\t")}`
dtsCont += '\n}'

dtsCont = `namespace ${rootPack.globalName} {
            ${dtsCont.replace(/\t/g, "\t\t")
        .replace(/\n/g, "\n\t")}
        \n}`
fs.outputFileSync(saveRoot + "/types/" + pack.globalname + ".d.ts", dtsCont)