/* eslint-disable */
export default {
  displayName: "fsm",
  // preset: '../../jest.preset.js',
  testMatch: ['**/+(*.)+(spec|test).+(ts|js)?(x)'],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx'],
  transform: {
      '^.+\\.tsx?$': 'ts-jest'
  }
};
