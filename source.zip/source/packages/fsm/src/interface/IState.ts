import { IStateMachine } from "./IStateMachine";

export interface IState {
    /**
     * 是否是状态机，用于区分子状态机和状态
     */
    isStateMachine : boolean;
    /**
     * 状态运行的时间
     */
    readonly elapsedTime: number;
    /**
     * 是否需要等待退出
     */
    needExitTime: boolean;
    /**
     * 状态id
     */
    stateId: number;

    /**
     * 状态对应的状态机
     */
    fsm: IStateMachine

    /**
     * 初始化状态
     */
    init();

    /**
     * 进入状态
     * @param prevState - 上一个状态 
     * @param param - 状态数据
     */
    onEnter(prevState: IState, param?: any): void

    /**
     * 离开状态
     * @param nextState - 下一个状态 
     * @param param - 数据
     */
    onExit(nextState: IState, param?: any): void

    /**
     * 状态持续函数
     * @param dt - 时间间隔
     */
    onUpdate(dt)

    /**
     * 请求离开状态
     */
    requestExit()
    
}