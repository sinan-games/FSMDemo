import { IState } from "./IState";

/**
 * 状态机接口
 */
export interface IStateMachine extends IState {
    /**
     * 当前状态
     */
    readonly activeState: IState
    /**
     * 当前激活的状态id
     */
    readonly activeID: number
    /**
     * 标记状态机能做状态跳转了
     */
    stateCanExit(): void

    /**
     * 请求修改状态
     * @param id - 目标状态
     * @param data - 数据
     * @param forceInstantly - 立即执行
     */
    requestStateChange(id: number,data?:any, forceInstantly?: boolean)

    /**
     * 停止状态机执行
     */
    stop()

}