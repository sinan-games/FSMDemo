import { IStateMachine } from "./IStateMachine";

/**
 * 状态转换信息
 */
export interface ITransition {
    from: number
    to: number
    /**
     * 附加数据
     */
    data?: any
    /**
     * 立即执行不等待完成
     */
    forceInstantly: boolean

    /**
     * 状态机
     */
    fsm: IStateMachine

    /**
     * 初始化
     */
    init()

    /**
     * 开始进入尝试转换
     */
    onEnter()

    /**
     * 是否可以状态转换
     */
    shouldTransition(): boolean
}