/**
 * 触发状态切换
 */
export interface ITriggerEvent {
    trigger(eventName: string)
}