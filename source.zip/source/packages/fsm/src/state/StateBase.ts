import { IState } from "../interface/IState";
import { IStateMachine } from "../interface/IStateMachine";

/**
 * 基础状态
 */
export class StateBase implements IState {
    isStateMachine = false

    private time = 0;
    
    get elapsedTime(): number {
        return this.time
    }

    
    needExitTime: boolean = false;
    
    stateId: number
    fsm: IStateMachine;
    
    init() {
    }
    
    onEnter(prevState: IState, param?: any): void {
        this.time = 0
    }
    
    onExit(nextState: IState, param?: any): void {
    }
    
    onUpdate(dt: any) {
        this.time += dt
    }

    
    requestExit() {
    }

}