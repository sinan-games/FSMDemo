import { TransitionBase } from "./TransitionBase";

/**
 * 一个常规的状态转换，可以根据特定条件
 */
export class Transition extends TransitionBase {
    /**
     * 转换条件回调
     */
    condition: (tran: Transition) => boolean

    /**
     * 构造
     * @param from - 
     * @param to - 
     * @param condition - 跳转条件
     * @param forceInstantly - 
     * @param data - 
     */
    constructor(
        from: number,
        to: number,
        condition: (tran: Transition) => boolean,
        forceInstantly: boolean = false,
        data: any = null
    ) {
        super(from, to, forceInstantly, data);
        this.condition = condition
    }

    
    shouldTransition(): boolean {
        if (this.condition) return this.condition(this)
        return super.shouldTransition()
    }
}