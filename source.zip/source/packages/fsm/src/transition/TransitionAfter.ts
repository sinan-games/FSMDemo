import { Transition } from "./Transition";

/**
 * 根据时间实现自动跳转状态
 */
export class TransitionAfter extends Transition {
    /**
     * 需要等待的时间
     */
    public delay: number;
    /**
     * 开始时间
     */
    private time: number

    /**
     * 当前执行的时间
     */
    public get runTime() {
        return (Date.now() - this.time) * 0.001
    }

    /**
     * 构造函数
     * @example
     * ```
     * let 东土大唐 = 0
     * let 西天 = 1
     * let 难 = 0
     * new TransitionAfter(东土大唐,西天,24*365*60*60,()=>难==9*9)
     * ```
     * @param from - 何处 
     * @param to - 去往何方
     * @param delay - 时间 
     * @param condition - 条件
     * @param forceInstantly - 是否强制 
     * @param data - 附加信息
     */
    constructor(
        from: number,
        to: number,
        delay: number,
        condition: (tran: Transition) => boolean = null,
        forceInstantly: boolean = false,
        data: any = null) {
        super(from, to, condition, forceInstantly, data)
        this.delay = delay
        this.time = Date.now()
    }
    
    onEnter() {
        this.time = Date.now()
    }
    
    shouldTransition(): boolean {
        if (this.runTime < this.delay) return false
        return this.condition == null || this.condition(this)
    }

}