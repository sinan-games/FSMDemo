import { IStateMachine } from "../interface/IStateMachine";
import { ITransition } from "../interface/ITransition";

/**
 * 基础转换
 */
export class TransitionBase implements ITransition {

    from: number;

    to: number;

    forceInstantly: boolean;
    data: any

    fsm: IStateMachine;

    /**
     * 构造
     * @param from - 当前状态名称
     * @param to - 目标名称
     * @param forceInstantly - 是否立即执行
     */
    constructor(from: number, to: number, forceInstantly: boolean = false, data: any = null) {
        this.from = from
        this.to = to
        this.forceInstantly = forceInstantly
        this.data = data
    }


    init() {
    }

    onEnter() {
    }

    shouldTransition(): boolean {
        return true
    }

}