import { defineConfig } from "tsup"
import pack from "./package.json"
import rootPack from "../../package.json"

import pluginGlobals from "esbuild-plugin-globals"
import { minify } from "terser";
import fs from "fs-extra";


let externalGlobals: { [key: string]: string } = {}
let externalGlobalNames = []
if (pack.external) {
    for (const key in pack.external) {
        externalGlobalNames.push(key)
        externalGlobals[key] = "window." + `${pack.external[key]}`
    }
}

let rootGlobalName = "window." + rootPack.globalName

export default defineConfig({
    bundle: true,
    dts: true,
    format: "iife",
    globalName: rootGlobalName + "." + pack.globalname,
    entry: ['src/index.ts'],
    external: externalGlobalNames,
    platform: "browser",
    outDir: "./dist",
    name: pack.name,
    outExtension({ format, options }) {
        return {
            js: '.js',
        }
    },
    async onSuccess() {
        let outputRoot = "./dist";
        let saveRoot = "../../dist";
        let jsPathName = outputRoot + "/index.js";
        let jsCont = fs.readFileSync(jsPathName,"utf8")
        jsCont = jsCont.replace('var window = window || {};',"")
        
        fs.outputFileSync(jsPathName,jsCont)
        
        fs.ensureDirSync(saveRoot)
        fs.ensureDirSync(outputRoot)
        fs.ensureDirSync(saveRoot + "/types")
        let saveTarget = saveRoot + "/" + pack.name + ".js"

        let saveMinTarget = saveRoot + "/min/" + pack.name + ".min.js"
       

       
        var result = await minify({
            "index.min.js": fs.readFileSync(jsPathName, "utf8")
        })
        fs.copyFileSync(jsPathName, saveTarget)
        fs.outputFileSync(saveMinTarget, result.code)
    },
    esbuildPlugins: [pluginGlobals(externalGlobals)]
})
