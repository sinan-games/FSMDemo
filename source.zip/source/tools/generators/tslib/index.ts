import {
  Tree,
  formatFiles,
  installPackagesTask,
  generateFiles,
  joinPathFragments,
  readProjectConfiguration,
  getProjects,
  readWorkspaceConfiguration
} from '@nrwl/devkit';

export default async function (tree: Tree, schema: any) {
  // await libraryGenerator(tree, { name: schema.name });
  // const project = getProjects(tree).get(schema.name);
  joinPathFragments()
  let workspace = readWorkspaceConfiguration(tree);

  const libraryRoot = joinPathFragments(workspace.workspaceLayout.libsDir + "/" + schema.name)
  await generateFiles(
    tree, // the virtual file system
    joinPathFragments(__dirname, 'files'), // path to the file templates
    libraryRoot, // destination path of the files
    { ...schema, tmpl: "" }
  );
  await formatFiles(tree);
  return () => {
    installPackagesTask(tree);
  };
}
